<div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="admin-profile.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-pencil-square-o"></i>
                        <span>Master Entry</span>
                    </a>
                    <ul class="sub">
                        <li><a href="add-games.php"><i class="fa fa-plus-circle"></i>Add Games</a></li>
                         <li><a href="employee-detail.php"><i class="fa fa-plus-circle"></i>Employee Detail Entry</a></li>
                         <li><a href="show-employeedetail.php"><i class="fa fa-plus-circle"></i>Show Employee Detail </a></li>
                    </ul>
                </li>             
                             
                
                <li class="sub-menu">
                    <a href="javascript:;">
                         <i class="fa fa-users"></i>
                        <span>Employee</span>
                    </a>
              <ul class="sub">
               <li><a href="unreg_employee.php"><i class="fa fa-user-times"></i>Unselected Employee</a></li>
                <li><a href="employee-entry.php"><i class="fa fa-plus"></i>&nbsp;Employee Entry</a></li>
                 <li><a href="selected-employee.php"><i class="fa fa-registered"></i>&nbsp;Selected Employee</a></li>
                 <li><a href="print.php"><i class="fa fa-registered"></i>&nbsp;Print Selected Employee</a></li>
               
              </ul>
                </li>
                
                 <li>
                    <a href="logout.php">
                        <i class="fa fa-user"></i>
                        <span>LogOut</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>