<div class="footer">
			<div class="wthree-copyright">
			  <p>© 2018 All rights reserved | Powered by <a href="#"></a></p>
			</div>
		  </div>